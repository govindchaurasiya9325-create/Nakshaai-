(function(){
  'use strict';
  var $ = function(id){ return document.getElementById(id); };
  var clamp = function(v,a,b){ return Math.min(b, Math.max(a, v)); };
  var f1 = function(n){ return String(Math.round(n*10)/10); };
  function el(tag, cls, text){ var e=document.createElement(tag); if(cls) e.className=cls; if(text!==undefined) e.textContent=text; return e; }

/* ---------- plan drawing ---------- */
  function drawPlan(m,key,uid){
    var P=m[key], W=m.W, L=m.L, s=m.s;
    var ml=30, mr=48, mt=36, mb=3*s+36;
    var vw=ml+W*s+mr, vh=mt+L*s+mb;
    var X=function(x){return ml+x*s;}, Y=function(y){return mt+(L-y)*s;};
    var fl=Math.max(7.5,Math.min(11.5,s*0.82)), fs=Math.max(6.5,fl-1.8);
    var o='<svg viewBox="0 0 '+f1(vw)+' '+f1(vh)+'" role="img" aria-label="'+(key==='g'?'Ground':'First')+' floor plan">';
    o+='<defs><pattern id="grid'+uid+'" width="'+s+'" height="'+s+'" patternUnits="userSpaceOnUse"><path d="M'+s+' 0H0V'+s+'" fill="none" stroke="var(--line)" stroke-width="0.5" opacity="0.55"/></pattern></defs>';
    o+='<rect x="'+X(0)+'" y="'+Y(L)+'" width="'+W*s+'" height="'+L*s+'" fill="url(#grid'+uid+')" stroke="var(--muted)" stroke-width="1" stroke-dasharray="4 3"/>';
    if(P.bal){
      var b=P.bal; o+='<rect x="'+X(b.x)+'" y="'+Y(b.y+b.h)+'" width="'+b.w*s+'" height="'+b.h*s+'" fill="var(--f-bal)" stroke="var(--wall)" stroke-width="1.2" stroke-dasharray="5 3"/>';
      o+='<text class="ls" x="'+X(W/2)+'" y="'+(Y(-1.5)+3)+'" text-anchor="middle" style="font-size:'+fs+'px">Balcony 3 ft</text>';
    }
    var fillOf={shop:'--f-shop',living:'--f-living',bed:'--f-bed',serv:'--f-serv',store:'--f-store',pass:'--f-pass',open:'--f-open',stair:'--f-stair'};
    P.rooms.forEach(function(r){
      o+='<rect x="'+f1(X(r.x))+'" y="'+f1(Y(r.y+r.h))+'" width="'+f1(r.w*s)+'" height="'+f1(r.h*s)+'" fill="var('+fillOf[r.t]+')" stroke="var(--wall)" stroke-width="'+(r.t==='open'?0.8:1.4)+'"'+(r.t==='open'?' stroke-dasharray="4 3"':'')+'/>';
      if(r.t==='stair'){
        var n=Math.floor(r.h/0.95);
        for(var k=1;k<n;k++){ var yy=Y(r.y+k*r.h/n); o+='<line x1="'+X(r.x+0.3)+'" x2="'+X(r.x+r.w-0.3)+'" y1="'+f1(yy)+'" y2="'+f1(yy)+'" stroke="var(--muted)" stroke-width="0.8"/>'; }
      }
    });
    P.furn.forEach(function(q){
      o+='<rect x="'+f1(X(q.x))+'" y="'+f1(Y(q.y+q.h))+'" width="'+f1(q.w*s)+'" height="'+f1(q.h*s)+'" rx="1.5" fill="var(--surface)" fill-opacity="0.55" stroke="var(--muted)" stroke-width="0.9"/>';
      if(q.tx && q.h*s>=14 && q.w*s>=26) o+='<text class="ls" x="'+f1(X(q.x+q.w/2))+'" y="'+f1(Y(q.y+q.h/2)+fs*0.35)+'" text-anchor="middle" style="font-size:'+(fs-0.5)+'px">'+q.tx+'</text>';
    });
    o+='<rect x="'+X(0)+'" y="'+Y(P.env.h)+'" width="'+W*s+'" height="'+P.env.h*s+'" fill="none" stroke="var(--wall)" stroke-width="4.5"/>';
    P.rooms.forEach(function(r){
      if(r.noSched && r.t==='pass' && r.sh==='Entry'){ lab(r,'Entry'); return; }
      var small=r.w*s<66;
      lab(r, small?r.sh:(r.ln||r.n), !small && r.t!=='open');
    });
    function lab(r,name,withSize){
      var cx=r.lx!==undefined?X(r.lx):X(r.x+r.w/2), cy=r.ly!==undefined?Y(r.ly):Y(r.y+r.h/2);
      var hasSize=withSize!==false && r.w*s>=40 && r.h*s>=30 && r.t!=='pass';
      if(r.t==='pass'&&r.h*s>60){ o+='<text class="ls" transform="translate('+f1(cx+3)+' '+f1(cy)+') rotate(-90)" text-anchor="middle" style="font-size:'+fs+'px">'+r.sh+'</text>'; return; }
      var dy=hasSize?-fl*0.15:fl*0.35;
      o+='<text class="lb" x="'+f1(cx)+'" y="'+f1(cy+dy)+'" text-anchor="middle" style="font-size:'+fl+'px">'+name+'</text>';
      if(hasSize) o+='<text class="ls" x="'+f1(cx)+'" y="'+f1(cy+fl*1.05)+'" text-anchor="middle" style="font-size:'+fs+'px">'+f1(r.w)+' × '+f1(r.h)+'</text>';
    }
    var col={d:'var(--door)',w:'var(--win)',s:'var(--shutter)',g:'var(--gate)'};
    P.doors.forEach(function(d){
      o+='<line x1="'+f1(X(d[1]))+'" y1="'+f1(Y(d[2]))+'" x2="'+f1(X(d[3]))+'" y2="'+f1(Y(d[4]))+'" stroke="'+col[d[0]]+'" stroke-width="'+(d[0]==='s'?5:3.6)+'"'+(d[0]==='g'?' stroke-dasharray="6 3"':'')+'/>';
    });
    var ty=mt-16;
    o+='<path class="dim" d="M'+X(0)+' '+ty+'H'+X(W)+'M'+X(0)+' '+(ty-5)+'V'+(ty+5)+'M'+X(W)+' '+(ty-5)+'V'+(ty+5)+'"/>';
    o+='<text class="ls" x="'+X(W/2)+'" y="'+(ty-5)+'" text-anchor="middle" style="font-size:'+fl+'px">'+W+' ft</text>';
    var rx=X(W)+16;
    o+='<path class="dim" d="M'+rx+' '+Y(L)+'V'+Y(0)+'M'+(rx-5)+' '+Y(L)+'H'+(rx+5)+'M'+(rx-5)+' '+Y(0)+'H'+(rx+5)+'"/>';
    o+='<text class="ls" transform="translate('+(rx+14)+' '+Y(L/2)+') rotate(90)" text-anchor="middle" style="font-size:'+fl+'px">'+L+' ft</text>';
    var ry=Y(-3)+10;
    o+='<rect x="'+X(0)+'" y="'+ry+'" width="'+W*s+'" height="18" rx="3" fill="var(--soft)" stroke="var(--line)"/>';
    o+='<text class="ls" x="'+X(W/2)+'" y="'+(ry+12.5)+'" text-anchor="middle" style="font-size:'+fs+'px;letter-spacing:.1em">ROAD · FRONT</text>';
    return o+'</svg>';
  }

  /* ---------- front elevation ---------- */
  function drawElev(m){
    var S=m.S, W=m.W, two=m.master, e=Math.min(14,300/W);
    var plinth=1.5, gh=10, sl=0.6, fh=10, par=3, mum=7;
    var topH=plinth+gh+sl+(two?fh:0), Htot=topH+par+(two?mum:0);
    var ml=24, mt=26, vw=ml+W*e+64, vh=mt+Htot*e+44;
    var X=function(x){return ml+x*e;}, Y=function(h){return mt+(Htot-h)*e;};
    var R=function(x,h0,w,h,fill,extra){ return '<rect x="'+f1(X(x))+'" y="'+f1(Y(h0+h))+'" width="'+f1(w*e)+'" height="'+f1(h*e)+'" fill="var('+fill+')"'+(extra||'')+'/>'; };
    var o='<svg viewBox="0 0 '+f1(vw)+' '+f1(vh)+'" role="img" aria-label="Front elevation">';
    var line=function(x1,y1,x2,y2,st,sw){ return '<line x1="'+f1(x1)+'" y1="'+f1(y1)+'" x2="'+f1(x2)+'" y2="'+f1(y2)+'" stroke="'+st+'" stroke-width="'+(sw||1)+'"/>'; };
    if(two){ o+=R(W-6,topH+par,5,mum,'--e-mum',' stroke="var(--wall)" stroke-width="1"'); o+=R(W-5,topH+par+3,3,1.6,'--e-glass',' stroke="var(--wall)" stroke-width="0.8"'); }
    o+=R(0,plinth,W,gh,'--e-wall',' stroke="var(--wall)" stroke-width="1"');
    o+=R(0,0,W,plinth,'--e-plinth',' stroke="var(--wall)" stroke-width="1"');
    if(S.shop){
      var sw=W-6;
      o+=R(1,plinth,sw,7.4,'--e-shutter',' stroke="var(--wall)" stroke-width="1"');
      for(var h=0.6;h<7.4;h+=0.6) o+=line(X(1),Y(plinth+h),X(1+sw),Y(plinth+h),'var(--wall)',0.5);
      o+=R(1,plinth+7.7,sw,1.9,'--e-sign',' stroke="var(--wall)" stroke-width="1"');
      o+='<text x="'+f1(X(1+sw/2))+'" y="'+f1(Y(plinth+7.7+0.95)+4)+'" text-anchor="middle" style="font:600 '+Math.max(9,e*0.95)+'px var(--font-m);letter-spacing:.2em;fill:var(--e-signink)">SHOP</text>';
      o+=R(W-3.5,plinth,3,7.2,'--e-door',' stroke="var(--wall)" stroke-width="1"');
      for(var b=0.5;b<3;b+=0.5) o+=line(X(W-3.5+b),Y(plinth),X(W-3.5+b),Y(plinth+7.2),'var(--wall)',0.5);
    } else {
      [2,8.5].forEach(function(x0){ o+=R(x0,plinth+3,4,4.6,'--e-glass',' stroke="var(--wall)" stroke-width="1"'); o+=line(X(x0+2),Y(plinth+3),X(x0+2),Y(plinth+7.6),'var(--wall)',1); });
      o+=R(W-4.5,plinth,3.5,7.2,'--e-door',' stroke="var(--wall)" stroke-width="1"');
    }
    var b1=plinth+gh;
    o+=R(-0.5,b1,W+1,sl,'--e-slab',' stroke="var(--wall)" stroke-width="1"');
    if(two){
      var base1=b1+sl;
      o+=R(0,base1,W,fh,'--e-wall',' stroke="var(--wall)" stroke-width="1"');
      var n=W>=26?4:3, ww=3.4, gap=(W-n*ww)/(n+1);
      for(var i=0;i<n;i++){ var wx=gap*(i+1)+ww*i;
        o+=R(wx,base1+2.6,ww,4.6,'--e-glass',' stroke="var(--wall)" stroke-width="1"');
        o+=line(X(wx+ww/2),Y(base1+2.6),X(wx+ww/2),Y(base1+7.2),'var(--wall)',1);
        o+=line(X(wx),Y(base1+4.9),X(wx+ww),Y(base1+4.9),'var(--wall)',1);
      }
      for(var q=0.25;q<W;q+=0.5) o+=line(X(q),Y(base1),X(q),Y(base1+3),'var(--e-rail)',0.8);
      o+=line(X(0),Y(base1+3),X(W),Y(base1+3),'var(--e-rail)',2.2);
    }
    o+=R(-0.2,topH,W+0.4,par,'--e-wall',' stroke="var(--wall)" stroke-width="1"');
    o+=R(-0.4,topH+par-0.4,W+0.8,0.4,'--e-slab',' stroke="var(--wall)" stroke-width="0.8"');
    o+=line(X(-2),Y(0),X(W+2),Y(0),'var(--wall)',2);
    var rx=X(W)+16, tall=topH+par;
    o+='<path class="dim" d="M'+rx+' '+Y(0)+'V'+Y(tall)+'M'+(rx-5)+' '+Y(0)+'H'+(rx+5)+'M'+(rx-5)+' '+Y(tall)+'H'+(rx+5)+'"/>';
    o+='<text class="ls" transform="translate('+(rx+14)+' '+Y(tall/2)+') rotate(90)" text-anchor="middle" style="font-size:11px">'+f1(tall)+' ft</text>';
    var by=Y(0)+18;
    o+='<path class="dim" d="M'+X(0)+' '+by+'H'+X(W)+'M'+X(0)+' '+(by-5)+'V'+(by+5)+'M'+X(W)+' '+(by-5)+'V'+(by+5)+'"/>';
    o+='<text class="ls" x="'+X(W/2)+'" y="'+(by+16)+'" text-anchor="middle" style="font-size:11px">'+W+' ft frontage</text>';
    return o+'</svg>';
  }

  
  /* ---------- state ---------- */
  var TABS=[['g','Ground floor','Ground floor plan'],['f','First floor','First floor plan'],['e','Front view','Front elevation']];
  var PRESETS=[
    {n:'21 × 40 shop + home', w:21,l:40,floors:2,beds:3,shop:true,store:true,sd:10},
    {n:'18 × 36 compact', w:18,l:36,floors:2,beds:2,shop:true,store:false,sd:9},
    {n:'20 × 50 family', w:20,l:50,floors:2,beds:4,shop:true,store:true,sd:10},
    {n:'25 × 50 no shop', w:25,l:50,floors:2,beds:4,shop:false,store:true,sd:10}
  ];
  var S={w:21,l:40,floors:2,beds:3,shop:true,store:true,sd:10};
  var M=null, tab='g', seq=0, timer=null, memId=null;

  function uuid(){
    if(window.crypto && crypto.randomUUID) return crypto.randomUUID();
    return 'c'+Date.now().toString(16)+Math.random().toString(16).slice(2)+'0000000000';
  }
  function clientId(){
    try{ var id=localStorage.getItem('naksha_client_id'); if(!id){ id=uuid(); localStorage.setItem('naksha_client_id',id); } return id; }
    catch(e){ if(!memId) memId=uuid(); return memId; }
  }

  /* ---------- API ---------- */
  function api(method, path, body, wantBlob){
    var opts={method:method, headers:{'X-Client-Id':clientId()}};
    if(body!==undefined){ opts.headers['Content-Type']='application/json'; opts.body=JSON.stringify(body); }
    return fetch(path, opts).then(function(res){
      if(res.ok){
        if(res.status===204) return null;
        return wantBlob ? res.blob() : res.json();
      }
      return res.json().catch(function(){ return {}; }).then(function(j){
        var msg=j.error||'Something went wrong.';
        if(j.details && j.details.length) msg+=' '+j.details.map(function(d){ return d.field+': '+d.message; }).join('; ');
        throw new Error(msg);
      });
    }, function(){ throw new Error('Cannot reach the server. Check your connection and try again.'); });
  }
  function download(blob, filename){
    var url=URL.createObjectURL(blob), a=document.createElement('a');
    a.href=url; a.download=filename; document.body.appendChild(a); a.click(); a.remove();
    setTimeout(function(){ URL.revokeObjectURL(url); }, 2000);
  }
  function slug(s){ return (s||'plan').replace(/[^A-Za-z0-9]+/g,'-').replace(/^-|-$/g,'').toLowerCase()||'plan'; }

  /* ---------- plan request ---------- */
  function requestPlan(){
    clearTimeout(timer);
    timer=setTimeout(function(){
      var my=++seq;
      api('POST','/api/plan',{params:S}).then(function(data){
        if(my!==seq) return;
        $('err').textContent='';
        M=data;
        if(data.S.floors!==S.floors){ S.floors=data.S.floors; sync(); }
        render();
      }).catch(function(e){ if(my===seq) $('err').textContent=e.message; });
    }, 90);
  }

  /* ---------- render ---------- */
  function render(){
    if(!M) return;
    var m=M;
    $('ptitle').textContent = m.W+' × '+m.L+' ft '+(S.shop?'shop-house':'house');
    $('psub').textContent = m.plot_area+' sq ft · '+m.gaj+' gaj · '+(m.master?'G+1':'Ground floor only')+' · '+m.placed+' bedroom'+(m.placed===1?'':'s')+(m.master?' (ground '+m.gb+', first '+(m.fb+1)+')':'');

    var tabs=$('tabs'); tabs.textContent='';
    TABS.forEach(function(t){
      var b=el('button',null,t[1]); b.type='button'; b.setAttribute('role','tab');
      var off = t[0]==='f' && !m.master;
      b.disabled=off; if(off && tab==='f') tab='g';
      b.setAttribute('aria-selected', String(tab===t[0]));
      b.addEventListener('click',function(){ tab=t[0]; render(); });
      tabs.appendChild(b);
    });
    $('drawing').innerHTML = tab==='e' ? drawElev(m) : drawPlan(m,tab,tab);
    var ti=TABS.filter(function(t){return t[0]===tab;})[0], si=TABS.indexOf(ti)+1;
    var area = tab==='g' ? m.gArea : tab==='f' ? m.fArea : null;
    var tb=$('tblock'); tb.textContent='';
    [['Sheet','0'+si+' / 03'],['Drawing',ti[2]],['Plot',m.W+' × '+m.L+' ft'],
     [area===null?'Height':'Built-up', area===null?(m.master?'G+1, 26 ft':'G, 15 ft'):'≈ '+Math.round(area)+' sq ft']].forEach(function(p){
      var d=el('div'); d.appendChild(el('b',null,p[0])); d.appendChild(el('span',null,p[1])); tb.appendChild(d);
    });

    var notes=$('notes'); notes.textContent='';
    m.notes.forEach(function(t){ notes.appendChild(el('div','note',t)); });

    var t=$('sched'); t.textContent='';
    var hr=el('tr'); hr.appendChild(el('th',null,'Room')); hr.appendChild(el('th','n','Size (ft)')); hr.appendChild(el('th','n','Area (sq ft)')); t.appendChild(hr);
    var cur=null;
    m.schedule.forEach(function(r){
      if(r.floor!==cur){ cur=r.floor; var sr=el('tr','sec'); var sc=el('td',null,cur); sc.colSpan=3; sr.appendChild(sc); t.appendChild(sr); }
      var tr=el('tr'); tr.appendChild(el('td',null,r.room)); tr.appendChild(el('td','n',f1(r.w)+' × '+f1(r.h))); tr.appendChild(el('td','n',String(r.area))); t.appendChild(tr);
    });
    $('summary').textContent = m.summary+'\nMade by Govind Chaurasiya (AI Engineer).';
  }

  /* ---------- controls ---------- */
  function seg(id,opts,get,set){
    var box=$(id); box.textContent='';
    opts.forEach(function(o){
      var b=el('button',null,o[1]); b.type='button'; b.setAttribute('aria-pressed',String(get()===o[0]));
      b.addEventListener('click',function(){ set(o[0]); sync(); requestPlan(); });
      box.appendChild(b);
    });
  }
  function sync(){
    $('w').value=S.w; $('l').value=S.l; $('shop').checked=S.shop; $('store').checked=S.store; $('sd').value=S.sd; $('sdout').textContent=S.sd;
    $('sdwrap').hidden=!S.shop;
    seg('floors',[[1,'G'],[2,'G+1']],function(){return S.floors;},function(v){S.floors=v;});
    seg('beds',[[1,'1'],[2,'2'],[3,'3'],[4,'4'],[5,'5']],function(){return S.beds;},function(v){S.beds=v;});
  }
  function readNum(id,a,b,key){
    var v=parseInt($(id).value,10);
    if(isNaN(v)||v<a||v>b) return false;
    S[key]=v; return true;
  }
  $('w').addEventListener('input',function(){ if(readNum('w',18,36,'w')) requestPlan(); });
  $('l').addEventListener('input',function(){ if(readNum('l',30,60,'l')) requestPlan(); });
  $('w').addEventListener('change',function(){ S.w=clamp(parseInt($('w').value,10)||S.w,18,36); sync(); requestPlan(); });
  $('l').addEventListener('change',function(){ S.l=clamp(parseInt($('l').value,10)||S.l,30,60); sync(); requestPlan(); });
  $('shop').addEventListener('change',function(){ S.shop=$('shop').checked; sync(); requestPlan(); });
  $('store').addEventListener('change',function(){ S.store=$('store').checked; requestPlan(); });
  $('sd').addEventListener('input',function(){ S.sd=parseInt($('sd').value,10); $('sdout').textContent=S.sd; requestPlan(); });
  PRESETS.forEach(function(p){
    var b=el('button','chip',p.n); b.type='button';
    b.addEventListener('click',function(){ S={w:p.w,l:p.l,floors:p.floors,beds:p.beds,shop:p.shop,store:p.store,sd:p.sd}; tab='g'; sync(); requestPlan(); });
    $('presets').appendChild(b);
  });

  /* ---------- save, load, delete, PDF ---------- */
  function setStatus(t){ $('status').textContent=t; }
  function busy(on){ $('save').disabled=on; $('pdf').disabled=on; }

  $('save').addEventListener('click',function(){
    var name=$('pname').value.trim();
    if(!name){ setStatus('Enter a name for this plan first.'); $('pname').focus(); return; }
    busy(true); setStatus('Saving…');
    api('POST','/api/projects',{name:name, params:S}).then(function(){
      setStatus('Saved.'); loadList();
    }).catch(function(e){ setStatus(e.message); }).then(function(){ busy(false); });
  });
  $('pdf').addEventListener('click',function(){
    var name=$('pname').value.trim();
    busy(true); setStatus('Making PDF…');
    api('POST','/api/plan/pdf',{name:name, params:S},true).then(function(blob){
      download(blob,'naksha-'+slug(name)+'.pdf'); setStatus('PDF downloaded.');
    }).catch(function(e){ setStatus(e.message); }).then(function(){ busy(false); });
  });
  $('pname').addEventListener('keydown',function(e){ if(e.key==='Enter'){ e.preventDefault(); $('save').click(); } });

  function loadList(){
    api('GET','/api/projects').then(function(d){
      var ul=$('plist'); ul.textContent='';
      $('pempty').hidden = d.projects.length>0;
      d.projects.forEach(function(p){
        var li=el('li'), info=el('div','pinfo');
        info.appendChild(el('span','pname',p.name));
        var dt=''; try{ dt=new Date(p.created_at).toLocaleDateString('en-IN',{day:'numeric',month:'short',year:'numeric'}); }catch(e){}
        info.appendChild(el('span','pmeta',p.params.w+' × '+p.params.l+' ft · '+p.bedrooms+' bed · '+dt));
        var btns=el('div','pbtns'), open=el('button','sm','Open'), del=el('button','sm danger','Delete');
        open.type='button'; del.type='button';
        open.addEventListener('click',function(){
          S={w:p.params.w,l:p.params.l,floors:p.params.floors,beds:p.params.beds,shop:p.params.shop,store:p.params.store,sd:p.params.sd};
          $('pname').value=p.name; tab='g'; sync(); requestPlan(); setStatus('Opened “'+p.name+'”.');
          window.scrollTo({top:0,behavior:'smooth'});
        });
        var armed=false, t2=null;
        del.addEventListener('click',function(){
          if(!armed){ armed=true; del.textContent='Confirm'; t2=setTimeout(function(){ armed=false; del.textContent='Delete'; },3000); return; }
          clearTimeout(t2);
          api('DELETE','/api/projects/'+p.id).then(loadList).catch(function(e){ setStatus(e.message); });
        });
        btns.appendChild(open); btns.appendChild(del);
        li.appendChild(info); li.appendChild(btns); ul.appendChild(li);
      });
    }).catch(function(e){ $('plist').textContent=''; $('pempty').hidden=false; $('pempty').textContent=e.message; });
  }

  /* ---------- describe your house ---------- */
  var EXAMPLES=['21 x 40 ka ghar, aage dukan, 3 bedroom, store room','25 x 50 plot, no shop, 4 bedrooms, G+1','18 feet chaudai 36 feet lambai, dukan aur 2 kamre'];
  EXAMPLES.forEach(function(x,i){
    var b=el('button','chip',['Example 1','Example 2','Example 3'][i]); b.type='button'; b.title=x;
    b.addEventListener('click',function(){ $('aitext').value=x; $('aitext').focus(); });
    $('aiex').appendChild(b);
  });
  function askAI(){
    var text=$('aitext').value.trim();
    var why=$('aiwhy'); why.textContent='';
    if(!text){ $('aistatus').textContent='Write a sentence first, for example: 21 x 40 ka ghar, aage dukan, 3 bedroom.'; $('aitext').focus(); return; }
    $('aigo').disabled=true; $('aistatus').textContent='Reading your description…';
    api('POST','/api/ai/parse',{text:text}).then(function(r){
      var p=r.params;
      S={w:p.w,l:p.l,floors:p.floors,beds:p.beds,shop:p.shop,store:p.store,sd:p.sd};
      tab='g'; sync(); requestPlan();
      $('aistatus').textContent=(r.source==='claude'?'Understood (Claude): ':'Understood (basic reader): ')+r.understood;
      r.assumptions.forEach(function(a){ why.appendChild(el('li',null,a)); });
    }).catch(function(e){ $('aistatus').textContent=e.message; }).then(function(){ $('aigo').disabled=false; });
  }
  $('aigo').addEventListener('click',askAI);
  $('aitext').addEventListener('keydown',function(e){ if(e.key==='Enter' && (e.ctrlKey||e.metaKey)){ e.preventDefault(); askAI(); } });

  sync(); requestPlan(); loadList();
})();
