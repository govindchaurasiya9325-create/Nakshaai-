"""Flask app: serves the page and a small JSON API."""
from __future__ import annotations

import os
import re
import sqlite3
import time
from collections import deque
from pathlib import Path

from flask import Flask, Response, g, jsonify, render_template, request
from pydantic import ValidationError

from naksha import ai, db
from naksha.engine import generate
from naksha.pdf import build_pdf
from naksha.schemas import PlanParams, PlanRequest, SaveRequest

BASE = Path(__file__).resolve().parent
CLIENT_ID_RE = re.compile(r"^[A-Za-z0-9-]{16,64}$")


def create_app(db_path: str | None = None) -> Flask:
    app = Flask(__name__)
    app.config["DB_PATH"] = db_path or os.environ.get("NAKSHA_DB", str(BASE / "instance" / "naksha.db"))
    app.config["MAX_CONTENT_LENGTH"] = 16 * 1024
    Path(app.config["DB_PATH"]).parent.mkdir(parents=True, exist_ok=True)
    with db.connect(app.config["DB_PATH"]) as conn:
        db.init_db(conn)

    def get_db() -> sqlite3.Connection:
        if "db" not in g:
            g.db = db.connect(app.config["DB_PATH"])
        return g.db

    @app.teardown_appcontext
    def close_db(_exc: BaseException | None) -> None:
        conn = g.pop("db", None)
        if conn is not None:
            conn.close()

    def error(message: str, status: int, details: list | None = None):
        body = {"error": message}
        if details:
            body["details"] = details
        return jsonify(body), status

    def client_id() -> str | None:
        cid = request.headers.get("X-Client-Id", "")
        return cid if CLIENT_ID_RE.match(cid) else None

    def parse(model):
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            raise ValueError("Send a JSON object.")
        return model.model_validate(data)

    @app.errorhandler(ValidationError)
    def on_validation(exc: ValidationError):
        details = [{"field": ".".join(str(p) for p in e["loc"]), "message": e["msg"]} for e in exc.errors()]
        return error("Invalid input.", 422, details)

    @app.errorhandler(ValueError)
    def on_value(exc: ValueError):
        return error(str(exc), 400)

    @app.errorhandler(413)
    def too_large(_exc):
        return error("Request is too large.", 413)

    @app.after_request
    def headers(resp: Response):
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("Referrer-Policy", "same-origin")
        if request.path.startswith("/api/"):
            resp.headers["Cache-Control"] = "no-store"
        return resp

    per_client: dict[str, deque] = {}
    overall: deque = deque()

    def allow_ai_call(cid: str) -> bool:
        """Limit paid AI calls: 8 per minute per browser and 60 per minute overall."""
        now = time.monotonic()
        for q in (overall, per_client.setdefault(cid, deque())):
            while q and now - q[0] > 60:
                q.popleft()
        if len(per_client[cid]) >= 8 or len(overall) >= 60:
            return False
        per_client[cid].append(now)
        overall.append(now)
        if len(per_client) > 5000:
            per_client.clear()
        return True

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        get_db().execute("SELECT 1").fetchone()
        return jsonify({"status": "ok"})

    @app.post("/api/plan")
    def plan():
        req = parse(PlanRequest)
        return jsonify(generate(req.params.model_dump()))

    @app.post("/api/plan/pdf")
    def plan_pdf():
        req = parse(PlanRequest)
        m = generate(req.params.model_dump())
        return _pdf_response(build_pdf(m, req.name), req.name)

    @app.post("/api/ai/parse")
    def ai_parse():
        cid = client_id()
        if not cid:
            return error("Missing or invalid X-Client-Id header.", 400)
        data = request.get_json(silent=True)
        text = ai.validate_text(data.get("text") if isinstance(data, dict) else None)
        api_key = os.environ.get("ANTHROPIC_API_KEY", "").strip()
        if api_key:
            if not allow_ai_call(cid):
                return error("Too many requests. Wait a minute and try again.", 429)
            try:
                result = ai.parse_with_claude(text, api_key)
            except Exception as exc:  # network, API or format problem: fall back to the basic reader
                app.logger.warning("AI parse failed: %s", type(exc).__name__)
                result = ai.parse_basic(text)
                result["assumptions"].insert(0, "The AI could not be reached, so the basic reader was used.")
        else:
            result = ai.parse_basic(text)
        PlanParams.model_validate(result["params"])
        return jsonify(result)

    @app.get("/api/projects")
    def list_projects():
        cid = client_id()
        if not cid:
            return error("Missing or invalid X-Client-Id header.", 400)
        return jsonify({"projects": db.list_projects(get_db(), cid)})

    @app.post("/api/projects")
    def save_project():
        cid = client_id()
        if not cid:
            return error("Missing or invalid X-Client-Id header.", 400)
        req = parse(SaveRequest)
        conn = get_db()
        if db.count_projects(conn, cid) >= db.MAX_PER_CLIENT:
            return error(f"You can save up to {db.MAX_PER_CLIENT} plans. Delete one first.", 409)
        m = generate(req.params.model_dump())
        saved = db.save_project(conn, cid, req.name, req.params.model_dump(), m["placed"], m["built_up"])
        return jsonify(saved), 201

    @app.get("/api/projects/<int:project_id>")
    def get_project(project_id: int):
        cid = client_id()
        if not cid:
            return error("Missing or invalid X-Client-Id header.", 400)
        row = db.get_project(get_db(), cid, project_id)
        return jsonify(row) if row else error("Plan not found.", 404)

    @app.get("/api/projects/<int:project_id>/pdf")
    def project_pdf(project_id: int):
        cid = client_id()
        if not cid:
            return error("Missing or invalid X-Client-Id header.", 400)
        row = db.get_project(get_db(), cid, project_id)
        if not row:
            return error("Plan not found.", 404)
        m = generate(row["params"])
        return _pdf_response(build_pdf(m, row["name"]), row["name"])

    @app.delete("/api/projects/<int:project_id>")
    def delete_project(project_id: int):
        cid = client_id()
        if not cid:
            return error("Missing or invalid X-Client-Id header.", 400)
        if not db.delete_project(get_db(), cid, project_id):
            return error("Plan not found.", 404)
        return "", 204

    return app


def _pdf_response(data: bytes, name: str) -> Response:
    slug = re.sub(r"[^A-Za-z0-9]+", "-", name).strip("-").lower() or "plan"
    resp = Response(data, mimetype="application/pdf")
    resp.headers["Content-Disposition"] = f'attachment; filename="naksha-{slug}.pdf"'
    return resp


app = create_app()

if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.environ.get("PORT", 5000)), debug=False)
