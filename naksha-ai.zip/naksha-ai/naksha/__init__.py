"""Naksha AI: shop-house floor plan generator."""
