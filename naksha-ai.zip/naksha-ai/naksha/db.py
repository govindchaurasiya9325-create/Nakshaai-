"""SQLite storage for saved plans.

Each browser gets a random client id (kept in localStorage). Saved plans belong to
that id, so one visitor never sees another visitor's plans. This is not a login.
"""
from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone

SCHEMA = """
CREATE TABLE IF NOT EXISTS projects (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   TEXT    NOT NULL,
    name        TEXT    NOT NULL,
    params      TEXT    NOT NULL,
    bedrooms    INTEGER NOT NULL,
    built_up    INTEGER NOT NULL,
    created_at  TEXT    NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_projects_client ON projects (client_id, id DESC);
"""

MAX_PER_CLIENT = 50


def connect(path: str) -> sqlite3.Connection:
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")
    return conn


def init_db(conn: sqlite3.Connection) -> None:
    conn.executescript(SCHEMA)
    conn.commit()


def _row(r: sqlite3.Row) -> dict:
    return {
        "id": r["id"],
        "name": r["name"],
        "params": json.loads(r["params"]),
        "bedrooms": r["bedrooms"],
        "built_up": r["built_up"],
        "created_at": r["created_at"],
    }


def count_projects(conn: sqlite3.Connection, client_id: str) -> int:
    return conn.execute("SELECT COUNT(*) FROM projects WHERE client_id = ?", (client_id,)).fetchone()[0]


def save_project(conn: sqlite3.Connection, client_id: str, name: str,
                 params: dict, bedrooms: int, built_up: int) -> dict:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    cur = conn.execute(
        "INSERT INTO projects (client_id, name, params, bedrooms, built_up, created_at) "
        "VALUES (?, ?, ?, ?, ?, ?)",
        (client_id, name, json.dumps(params, sort_keys=True), bedrooms, built_up, now),
    )
    conn.commit()
    return get_project(conn, client_id, cur.lastrowid)  # type: ignore[return-value]


def list_projects(conn: sqlite3.Connection, client_id: str, limit: int = MAX_PER_CLIENT) -> list[dict]:
    rows = conn.execute(
        "SELECT * FROM projects WHERE client_id = ? ORDER BY id DESC LIMIT ?", (client_id, limit)
    ).fetchall()
    return [_row(r) for r in rows]


def get_project(conn: sqlite3.Connection, client_id: str, project_id: int) -> dict | None:
    r = conn.execute(
        "SELECT * FROM projects WHERE id = ? AND client_id = ?", (project_id, client_id)
    ).fetchone()
    return _row(r) if r else None


def delete_project(conn: sqlite3.Connection, client_id: str, project_id: int) -> bool:
    cur = conn.execute("DELETE FROM projects WHERE id = ? AND client_id = ?", (project_id, client_id))
    conn.commit()
    return cur.rowcount > 0
