"""Rule-based layout engine for a shop-house on a rectangular plot.

All lengths are in feet. The plan origin is the front-left corner of the plot:
x runs left to right, y runs from the road (y = 0) to the back of the plot.
"""
from __future__ import annotations

import math
from typing import Any


def _round(x: float) -> int:
    """Round half up, the same way JavaScript's Math.round does."""
    return int(math.floor(x + 0.5))


def f1(n: float) -> str:
    v = math.floor(n * 10 + 0.5) / 10
    return str(int(v)) if v == int(v) else str(v)


def _room(rooms: list, name: str, short: str, kind: str,
          x: float, y: float, w: float, h: float, **extra: Any) -> dict:
    r = {"n": name, "sh": short or name, "t": kind, "x": x, "y": y, "w": w, "h": h}
    r.update(extra)
    rooms.append(r)
    return r


def build_raw(p: dict) -> dict:
    """Lay out the plot exactly as requested, without any automatic changes."""
    W, L = p["w"], p["l"]
    notes: list[str] = []

    sd = p["sd"] if p["shop"] else 8
    hd = 10
    yh = sd + hd
    rd = L - yh
    zd = 28 if rd > 31 else rd
    rw = 7 if W <= 24 else _round(W / 3)
    g = 3
    bw = W - rw - g
    x0r = bw + g
    cap_g = max(1, math.floor(zd / 9))

    master = p["floors"] == 2
    fb = 0
    if not master:
        gb = min(p["beds"], cap_g)
    else:
        r = p["beds"] - 1
        gb = min(r, cap_g)
        fb = min(r - gb, cap_g)

    placed = gb + fb + (1 if master else 0)
    if placed < p["beds"]:
        tail = "Choose G+1 to add more." if p["floors"] == 1 else "A longer plot is needed for more."
        notes.append(f"This plot fits {placed} bedroom{'' if placed == 1 else 's'} with the current settings. {tail}")

    nb = max(gb, 1)
    bd = min(zd / nb, 12)
    left = zd - nb * bd
    if left < 5:
        bd = zd / nb
        left = 0
    if gb == 0:
        bd = 0
        left = zd

    kd = max(8, min(12, _round(zd * 0.45)))
    a_d = min(11, zd - kd)
    band_b = zd - a_d - kd
    wc_h = min(7, a_d - 3.5)
    if master and a_d < 10:
        notes.append(f"The staircase run is {f1(a_d)} ft, which is tight for a 10 ft floor height. "
                     "A longer plot gives a comfortable stair.")

    G: list = []
    GF: list = []
    GD: list = []
    GW: list = []

    # ---- ground floor ----
    if p["shop"]:
        _room(G, "Shop (Dukan)", "Shop", "shop", 0, 0, W - 4, sd)
        _room(G, "Entry", "Entry", "pass", W - 4, 0, 4, sd, noSched=True)
        GF.append({"x": 1, "y": sd - 2.6, "w": W - 6, "h": 1.8, "tx": "Counter"})
        GD += [["s", 1, 0, W - 5, 0], ["g", W - 3.5, 0, W - 0.5, 0],
               ["d", W - 4, 3.5, W - 4, 6], ["d", W - 3.5, sd, W - 0.5, sd]]
    else:
        _room(G, "Parking / Sit-out", "Parking", "open", 0, 0, W, sd)
        GD += [["g", 2, 0, W - 2, 0], ["d", W - 3.5, sd, W - 0.5, sd]]

    store_area = 30 if p["store"] else 0
    _room(G, "Hall + Dining", "Hall", "living", 0, sd, W, hd,
          area=W * hd - store_area, lx=(6 + W) / 2, ly=sd + 1.7)
    tx = (W - 5) / 2 + 1
    GF.append({"x": 1, "y": sd + 7.2, "w": 6.5, "h": 2.5, "tx": "Sofa"})
    GF.append({"x": tx, "y": sd + 5, "w": 5, "h": 3, "tx": "Table"})
    for cx, cy in [(tx + 0.4, sd + 8.2), (tx + 3.4, sd + 8.2), (tx + 0.4, sd + 3.7),
                   (tx + 3.4, sd + 3.7), (tx - 1.3, sd + 5.9), (tx + 5.1, sd + 5.9)]:
        GF.append({"x": cx, "y": cy, "w": 1.2, "h": 1.2})

    if p["store"]:
        _room(G, "Store", "Store", "store", 0, sd, 6, 5)
        if p["shop"]:
            GD.append(["d", 1.5, sd, 4, sd])
        GD.append(["d", 1.5, sd + 5, 4, sd + 5])
    wy = sd + (6 if p["store"] else 3.5)
    GW.append(["w", 0, wy, 0, sd + (9 if p["store"] else 6.5)])

    for i in range(gb):
        by = yh + i * bd
        rr = _room(G, f"Bedroom {i + 1}", "Bed", "bed", 0, by, bw, bd,
                   lx=(bw - 5.6) / 2, ly=by + bd / 2)
        if bw >= 9 and bd >= 8.5:
            GF.append({"x": bw - 5.6, "y": by + bd / 2 - 3.1, "w": 5.2, "h": 6.2, "tx": "Bed"})
        else:
            rr.pop("lx", None)
        GD.append(["d", bw, by + bd / 2 - 1.25, bw, by + bd / 2 + 1.25])
        GW.append(["w", 0, by + bd / 2 - 1.75, 0, by + bd / 2 + 1.75])

    if left > 0:
        sy = yh + gb * bd
        _room(G, "Study / Guest", "Study", "store", 0, sy, bw, left)
        GD.append(["d", bw, sy + left / 2 - 1.25, bw, sy + left / 2 + 1.25])
        GW.append(["w", 0, sy + left / 2 - 1.5, 0, sy + left / 2 + 1.5])

    _room(G, "Gali (passage)", "Gali", "pass", bw, yh, g, zd, noSched=True)
    GD.append(["d", bw + 0.4, yh, bw + g - 0.4, yh])
    _room(G, "WC", "WC", "serv", x0r, yh, rw - 4, wc_h)
    GD.append(["d", x0r, yh + wc_h / 2 - 1, x0r, yh + wc_h / 2 + 1])
    _room(G, "Wash", "Wash", "serv", x0r, yh + wc_h, rw - 4, a_d - wc_h)
    if a_d - wc_h >= 2.5:
        mid = yh + wc_h + (a_d - wc_h) / 2
        GD.append(["d", x0r, mid - 1, x0r, mid + 1])
    if master:
        _room(G, "Staircase", "Stair", "stair", W - 4, yh, 4, a_d)
    else:
        _room(G, "Utility", "Utility", "store", W - 4, yh, 4, a_d)
    GD.append(["d", W - 3.2, yh, W - 0.8, yh])
    if band_b >= 3:
        _room(G, "Utility / Store", "Utility", "store", x0r, yh + a_d, rw, band_b)
        m2 = yh + a_d + band_b / 2
        GD.append(["d", x0r, m2 - 1, x0r, m2 + 1])
    ky = yh + a_d + band_b
    _room(G, "Kitchen", "Kitchen", "serv", x0r, ky, rw, kd)
    GF.append({"x": x0r + 0.3, "y": ky + kd - 2.3, "w": rw - 0.6, "h": 2})
    GD.append(["d", x0r, ky + kd / 2 - 1.25, x0r, ky + kd / 2 + 1.25])
    GW.append(["w", x0r + rw / 2 - 1.5, yh + zd, x0r + rw / 2 + 1.5, yh + zd])
    if L - (yh + zd) >= 3:
        _room(G, "Open yard", "Yard", "open", 0, yh + zd, W, L - yh - zd)

    # ---- first floor ----
    F: list = []
    FF: list = []
    FD: list = []
    FW: list = []
    fd = 11
    if master:
        _room(F, "Master Bedroom", "Master", "bed", 0, 0, W, fd,
              area=W * fd - 36, lx=(W - 6) / 2, ly=1.9, ln="Master Bedroom")
        FF.append({"x": 4, "y": 4.2, "w": 6, "h": 6.2, "tx": "Bed"})
        _room(F, "Attached bath", "Bath", "serv", W - 6, fd - 6, 6, 6)
        _room(F, "Family lounge", "Lounge", "living", 0, fd, W, yh - fd)
        _room(F, "Open terrace", "Terrace", "open", 0, yh, W, zd,
              lx=max(5, (W - 4) / 2), ly=yh + zd * 0.62)
        for j in range(fb):
            ey = yh + j * bd
            er = _room(F, f"Bedroom {gb + j + 1}", "Bed", "bed", 0, ey, bw, bd,
                       lx=(bw - 5.6) / 2, ly=ey + bd / 2)
            if bw >= 9 and bd >= 8.5:
                FF.append({"x": bw - 5.6, "y": ey + bd / 2 - 3.1, "w": 5.2, "h": 6.2, "tx": "Bed"})
            else:
                er.pop("lx", None)
            FD.append(["d", bw, ey + bd / 2 - 1.25, bw, ey + bd / 2 + 1.25])
            FW.append(["w", 0, ey + bd / 2 - 1.75, 0, ey + bd / 2 + 1.75])
        if fb > 0:
            _room(F, "Gali (passage)", "Gali", "pass", bw, yh, g, fb * bd, noSched=True)
            FD.append(["d", bw + 0.4, yh, bw + g - 0.4, yh])
        _room(F, "Staircase", "Stair", "stair", W - 4, yh, 4, a_d)
        FD += [["d", W - 3.2, yh, W - 0.8, yh], ["d", 3, fd, 5.5, fd],
               ["d", W - 6, fd - 4, W - 6, fd - 1.5], ["d", 4, 0, 7.5, 0]]
        FW += [["w", 0, 3, 0, 6.5], ["w", 0, fd + 2.5, 0, fd + 5.5]]

    g_area = W * (yh + zd)
    f_area = W * yh + 4 * a_d + fb * bw * bd if master else 0
    bal = {"x": 0, "y": -3, "w": W, "h": 3} if master else None

    return {
        "S": dict(p), "W": W, "L": L, "sd": sd, "hd": hd, "yh": yh, "zd": zd, "bw": bw,
        "rw": rw, "aD": a_d, "gb": gb, "fb": fb, "master": master,
        "g": {"rooms": G, "furn": GF, "doors": GD + GW, "env": {"w": W, "h": yh + zd}},
        "f": {"rooms": F, "furn": FF, "doors": FD + FW, "env": {"w": W, "h": yh + zd}, "bal": bal},
        "notes": notes, "gArea": g_area, "fArea": f_area, "s": min(14, 300 / W),
    }


def _schedule(m: dict) -> list[dict]:
    rows = []
    for floor_key, label in (("g", "Ground floor"), ("f", "First floor")):
        if floor_key == "f" and not m["master"]:
            continue
        for r in m[floor_key]["rooms"]:
            if r.get("noSched"):
                continue
            area = r["area"] if "area" in r else r["w"] * r["h"]
            rows.append({"floor": label, "room": r["n"], "w": r["w"], "h": r["h"], "area": _round(area)})
    return rows


def generate(p: dict) -> dict:
    """Build the plan. If the bedrooms do not fit on one floor, switch to G+1."""
    p = dict(p)
    m = build_raw(p)
    placed = m["gb"] + m["fb"] + (1 if m["master"] else 0)
    auto = False
    if p["floors"] == 1 and placed < p["beds"]:
        p["floors"] = 2
        m = build_raw(p)
        auto = True
        placed = m["gb"] + m["fb"] + 1
    if auto:
        m["notes"].insert(0, f"All {p['beds']} bedrooms do not fit on one floor, so the plan switched to G+1. "
                             "Extra bedrooms go on the first floor.")
    m["notes"].append("Windows are drawn on the left and rear walls. If the left wall touches a neighbour, "
                      "keep a small ventilation shaft instead.")
    if m["master"]:
        m["notes"].append("The balcony projects 3 ft beyond the front wall. "
                          "Check your local setback rules before you finalise it.")

    plot = m["W"] * m["L"]
    m["placed"] = placed
    m["plot_area"] = plot
    m["gaj"] = round(plot / 9, 1)
    m["auto_upgraded"] = auto
    m["built_up"] = _round(m["gArea"] + m["fArea"])
    m["schedule"] = _schedule(m)
    shop_txt = f"Shop {m['W'] - 4} x {m['sd']} ft at the front with a 4 ft side entry. " if p["shop"] else ""
    store_txt = "Store room 6 x 5 ft. " if p["store"] else ""
    m["summary"] = (
        f"{m['W']} x {m['L']} ft plot ({plot} sq ft, {f1(plot / 9)} gaj), "
        f"{'G+1' if p['floors'] == 2 else 'ground floor'}, {placed} bedroom{'' if placed == 1 else 's'}.\n"
        f"{shop_txt}{store_txt}Hall + dining {m['W']} x 10 ft, kitchen, common WC and staircase at the back.\n"
        f"Built-up area about {m['built_up']} sq ft."
    )
    return m
