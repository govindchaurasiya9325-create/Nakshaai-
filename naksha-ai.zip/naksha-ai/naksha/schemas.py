"""Request validation with pydantic."""
from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator


class PlanParams(BaseModel):
    model_config = ConfigDict(extra="forbid")

    w: int = Field(ge=18, le=36, description="Plot width in feet")
    l: int = Field(ge=30, le=60, description="Plot length in feet")
    floors: int = Field(ge=1, le=2)
    beds: int = Field(ge=1, le=5)
    shop: bool
    store: bool
    sd: int = Field(default=10, ge=8, le=14, description="Shop depth in feet")


class PlanRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    params: PlanParams
    name: str = Field(default="", max_length=60)

    @field_validator("name")
    @classmethod
    def _strip(cls, v: str) -> str:
        return v.strip()


class SaveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")

    params: PlanParams
    name: str = Field(min_length=1, max_length=60)

    @field_validator("name")
    @classmethod
    def _strip(cls, v: str) -> str:
        v = v.strip()
        if not v:
            raise ValueError("Name cannot be empty")
        return v
