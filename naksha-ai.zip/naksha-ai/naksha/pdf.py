"""PDF export with ReportLab: floor plans, front elevation and room schedule."""
from __future__ import annotations

import io
from datetime import date

from reportlab.lib.colors import HexColor, black, white
from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

PAGE_W, PAGE_H = A4
MARGIN = 48
AUTHOR = "Govind Chaurasiya (AI Engineer)"

INK = HexColor("#11202E")
MUTED = HexColor("#5B6B7A")
LINE = HexColor("#C9D3DD")
ACCENT = HexColor("#1D4ED8")

FILL = {
    "shop": "#FBE1D1", "living": "#E9EEF3", "bed": "#D3EEE9", "serv": "#DCE3F5",
    "store": "#F8EBC6", "pass": "#E3E7EB", "open": "#DDEFD8", "stair": "#D7D9DE",
}
OPENING = {"d": "#C2410C", "w": "#2563EB", "s": "#B45309", "g": "#15803D"}

E_WALL, E_PLINTH, E_SHUTTER = "#DDE3E9", "#AAB4BE", "#6B7785"
E_DOOR, E_GLASS, E_SLAB, E_RAIL, E_MUM = "#7B5A3C", "#BFD8F2", "#B8C1CA", "#44505C", "#CBD3DB"


def _fmt(n: float) -> str:
    v = round(n * 10) / 10
    return str(int(v)) if v == int(v) else str(v)


def _header(c: canvas.Canvas, title: str, name: str, subtitle: str) -> None:
    c.setFillColor(ACCENT)
    c.rect(MARGIN, PAGE_H - MARGIN - 20, 22, 22, stroke=0, fill=1)
    c.setStrokeColor(white)
    c.setLineWidth(1.4)
    c.rect(MARGIN + 5, PAGE_H - MARGIN - 15, 12, 12, stroke=1, fill=0)
    c.setFillColor(INK)
    c.setFont("Helvetica-Bold", 16)
    c.drawString(MARGIN + 32, PAGE_H - MARGIN - 6, "Naksha AI")
    c.setFont("Helvetica", 9)
    c.setFillColor(MUTED)
    c.drawString(MARGIN + 32, PAGE_H - MARGIN - 18, name or "Untitled plan")
    c.setFont("Helvetica-Bold", 12)
    c.setFillColor(INK)
    c.drawRightString(PAGE_W - MARGIN, PAGE_H - MARGIN - 6, title)
    c.setFont("Helvetica", 9)
    c.setFillColor(MUTED)
    c.drawRightString(PAGE_W - MARGIN, PAGE_H - MARGIN - 18, subtitle)
    c.setStrokeColor(INK)
    c.setLineWidth(1.2)
    c.line(MARGIN, PAGE_H - MARGIN - 28, PAGE_W - MARGIN, PAGE_H - MARGIN - 28)


def _footer(c: canvas.Canvas, page: int, total: int) -> None:
    c.setStrokeColor(LINE)
    c.setLineWidth(0.6)
    c.line(MARGIN, MARGIN + 6, PAGE_W - MARGIN, MARGIN + 6)
    c.setFont("Helvetica", 8)
    c.setFillColor(MUTED)
    c.drawString(MARGIN, MARGIN - 6, f"Made by {AUTHOR}")
    c.drawCentredString(PAGE_W / 2, MARGIN - 6, "Concept drawing. Not for construction.")
    c.drawRightString(PAGE_W - MARGIN, MARGIN - 6, f"{date.today().isoformat()}   {page}/{total}")


def _dim_h(c: canvas.Canvas, x0: float, x1: float, y: float, label: str) -> None:
    c.setStrokeColor(MUTED)
    c.setLineWidth(0.7)
    c.line(x0, y, x1, y)
    c.line(x0, y - 3, x0, y + 3)
    c.line(x1, y - 3, x1, y + 3)
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 8)
    c.drawCentredString((x0 + x1) / 2, y + 4, label)


def _dim_v(c: canvas.Canvas, x: float, y0: float, y1: float, label: str) -> None:
    c.setStrokeColor(MUTED)
    c.setLineWidth(0.7)
    c.line(x, y0, x, y1)
    c.line(x - 3, y0, x + 3, y0)
    c.line(x - 3, y1, x + 3, y1)
    c.saveState()
    c.translate(x + 11, (y0 + y1) / 2)
    c.rotate(90)
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 8)
    c.drawCentredString(0, 0, label)
    c.restoreState()


def _draw_plan(c: canvas.Canvas, m: dict, key: str, x0: float, y0: float, s: float) -> None:
    plan = m[key]
    W, L = m["W"], m["L"]

    c.setStrokeColor(MUTED)
    c.setLineWidth(0.6)
    c.setDash(3, 3)
    c.rect(x0, y0, W * s, L * s, stroke=1, fill=0)
    c.setDash()

    bal = plan.get("bal")
    if bal:
        c.setFillColor(HexColor("#EDEFF2"))
        c.setStrokeColor(INK)
        c.setLineWidth(0.8)
        c.setDash(4, 3)
        c.rect(x0 + bal["x"] * s, y0 + bal["y"] * s, bal["w"] * s, bal["h"] * s, stroke=1, fill=1)
        c.setDash()
        c.setFillColor(MUTED)
        c.setFont("Helvetica", 7)
        c.drawCentredString(x0 + W * s / 2, y0 + bal["y"] * s + bal["h"] * s / 2 - 2, "Balcony 3 ft")

    for r in plan["rooms"]:
        c.setFillColor(HexColor(FILL[r["t"]]))
        c.setStrokeColor(INK)
        c.setLineWidth(0.5 if r["t"] == "open" else 1.0)
        if r["t"] == "open":
            c.setDash(3, 2)
        c.rect(x0 + r["x"] * s, y0 + r["y"] * s, r["w"] * s, r["h"] * s, stroke=1, fill=1)
        c.setDash()
        if r["t"] == "stair":
            n = int(r["h"] // 0.95)
            c.setStrokeColor(MUTED)
            c.setLineWidth(0.5)
            for k in range(1, n):
                yy = y0 + (r["y"] + k * r["h"] / n) * s
                c.line(x0 + (r["x"] + 0.3) * s, yy, x0 + (r["x"] + r["w"] - 0.3) * s, yy)

    for q in plan["furn"]:
        c.setFillColor(white)
        c.setStrokeColor(MUTED)
        c.setLineWidth(0.5)
        c.rect(x0 + q["x"] * s, y0 + q["y"] * s, q["w"] * s, q["h"] * s, stroke=1, fill=1)
        if q.get("tx") and q["h"] * s >= 12 and q["w"] * s >= 22:
            c.setFillColor(MUTED)
            c.setFont("Helvetica", 6.5)
            c.drawCentredString(x0 + (q["x"] + q["w"] / 2) * s, y0 + (q["y"] + q["h"] / 2) * s - 2, q["tx"])

    c.setStrokeColor(INK)
    c.setLineWidth(3)
    c.rect(x0, y0, plan["env"]["w"] * s, plan["env"]["h"] * s, stroke=1, fill=0)

    fs = max(6.5, min(9, s * 0.72))
    for r in plan["rooms"]:
        if r.get("noSched") and r["sh"] == "Gali":
            if r["h"] * s > 60:
                c.saveState()
                c.translate(x0 + (r["x"] + r["w"] / 2) * s + 3, y0 + (r["y"] + r["h"] / 2) * s)
                c.rotate(90)
                c.setFillColor(MUTED)
                c.setFont("Helvetica", 7)
                c.drawCentredString(0, 0, "Gali")
                c.restoreState()
            continue
        small = r["w"] * s < 62
        name = r["sh"] if small else r.get("ln", r["n"])
        cx = x0 + (r["lx"] if "lx" in r else r["x"] + r["w"] / 2) * s
        cy = y0 + (r["ly"] if "ly" in r else r["y"] + r["h"] / 2) * s
        sized = not small and r["w"] * s >= 40 and r["h"] * s >= 28 and r["t"] not in ("pass", "open")
        c.setFillColor(INK)
        c.setFont("Helvetica-Bold", fs)
        c.drawCentredString(cx, cy + (2 if sized else -fs * 0.3), name)
        if sized:
            c.setFont("Helvetica", fs - 1.5)
            c.setFillColor(MUTED)
            c.drawCentredString(cx, cy - fs - 0.5, f"{_fmt(r['w'])} x {_fmt(r['h'])}")

    for kind, ax, ay, bx, by in plan["doors"]:
        c.setStrokeColor(HexColor(OPENING[kind]))
        c.setLineWidth(3.6 if kind == "s" else 2.6)
        c.setDash(5, 2.5) if kind == "g" else c.setDash()
        c.line(x0 + ax * s, y0 + ay * s, x0 + bx * s, y0 + by * s)
    c.setDash()

    _dim_h(c, x0, x0 + W * s, y0 + L * s + 14, f"{W} ft")
    _dim_v(c, x0 + W * s + 14, y0, y0 + L * s, f"{L} ft")

    c.setFillColor(HexColor("#E7ECF2"))
    c.setStrokeColor(LINE)
    c.setLineWidth(0.6)
    ry = y0 - 3 * s - 24 if bal else y0 - 24
    c.rect(x0, ry, W * s, 14, stroke=1, fill=1)
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 7)
    c.drawCentredString(x0 + W * s / 2, ry + 4, "ROAD  -  FRONT")


def _legend(c: canvas.Canvas, x: float, y: float) -> None:
    c.setFont("Helvetica", 8)
    for label, key in (("Door", "d"), ("Window", "w"), ("Shutter", "s"), ("Gate", "g")):
        c.setStrokeColor(HexColor(OPENING[key]))
        c.setLineWidth(3)
        c.line(x, y + 2.5, x + 14, y + 2.5)
        c.setFillColor(MUTED)
        c.drawString(x + 19, y, label)
        x += 66


def _draw_elevation(c: canvas.Canvas, m: dict, x0: float, y0: float, e: float) -> float:
    S, W, two = m["S"], m["W"], m["master"]
    plinth, gh, sl, fh, par, mum = 1.5, 10, 0.6, 10, 3, 7
    top_h = plinth + gh + sl + (fh if two else 0)
    total = top_h + par + (mum if two else 0)

    def rect(x, h0, w, h, fill, stroke=True):
        c.setFillColor(HexColor(fill))
        c.setStrokeColor(INK)
        c.setLineWidth(0.7)
        c.rect(x0 + x * e, y0 + h0 * e, w * e, h * e, stroke=1 if stroke else 0, fill=1)

    def line(xa, ha, xb, hb, color=INK, lw=0.6):
        c.setStrokeColor(HexColor(color) if isinstance(color, str) else color)
        c.setLineWidth(lw)
        c.line(x0 + xa * e, y0 + ha * e, x0 + xb * e, y0 + hb * e)

    if two:
        rect(W - 6, top_h + par, 5, mum, E_MUM)
        rect(W - 5, top_h + par + 3, 3, 1.6, E_GLASS)
    rect(0, plinth, W, gh, E_WALL)
    rect(0, 0, W, plinth, E_PLINTH)

    if S["shop"]:
        sw = W - 6
        rect(1, plinth, sw, 7.4, E_SHUTTER)
        h = 0.6
        while h < 7.4:
            line(1, plinth + h, 1 + sw, plinth + h, INK, 0.3)
            h += 0.6
        rect(1, plinth + 7.7, sw, 1.9, "#1D4ED8")
        c.setFillColor(white)
        c.setFont("Helvetica-Bold", max(7, e * 0.9))
        c.drawCentredString(x0 + (1 + sw / 2) * e, y0 + (plinth + 7.7 + 0.95) * e - 3, "S H O P")
        rect(W - 3.5, plinth, 3, 7.2, E_DOOR)
    else:
        for xx in (2, 8.5):
            rect(xx, plinth + 3, 4, 4.6, E_GLASS)
            line(xx + 2, plinth + 3, xx + 2, plinth + 7.6)
        rect(W - 4.5, plinth, 3.5, 7.2, E_DOOR)

    b1 = plinth + gh
    rect(-0.5, b1, W + 1, sl, E_SLAB)
    if two:
        base = b1 + sl
        rect(0, base, W, fh, E_WALL)
        n = 4 if W >= 26 else 3
        ww = 3.4
        gap = (W - n * ww) / (n + 1)
        for i in range(n):
            wx = gap * (i + 1) + ww * i
            rect(wx, base + 2.6, ww, 4.6, E_GLASS)
            line(wx + ww / 2, base + 2.6, wx + ww / 2, base + 7.2)
            line(wx, base + 4.9, wx + ww, base + 4.9)
        q = 0.25
        while q < W:
            line(q, base, q, base + 3, E_RAIL, 0.5)
            q += 0.5
        line(0, base + 3, W, base + 3, E_RAIL, 1.6)
    rect(-0.2, top_h, W + 0.4, par, E_WALL)
    rect(-0.4, top_h + par - 0.4, W + 0.8, 0.4, E_SLAB)
    line(-2, 0, W + 2, 0, INK, 1.6)

    tall = top_h + par
    _dim_v(c, x0 + W * e + 14, y0, y0 + tall * e, f"{_fmt(tall)} ft")
    _dim_h(c, x0, x0 + W * e, y0 - 22, f"{W} ft frontage")
    return total * e


def _draw_schedule(c: canvas.Canvas, m: dict, x: float, y: float, width: float) -> None:
    c.setFont("Helvetica-Bold", 11)
    c.setFillColor(INK)
    c.drawString(x, y, "Room schedule")
    y -= 14
    c.setFont("Helvetica", 7.5)
    c.setFillColor(MUTED)
    c.drawString(x, y, "ROOM")
    c.drawRightString(x + width - 70, y, "SIZE (FT)")
    c.drawRightString(x + width, y, "AREA (SQ FT)")
    y -= 5
    c.setStrokeColor(LINE)
    c.line(x, y, x + width, y)
    y -= 11
    current = None
    for row in m["schedule"]:
        if row["floor"] != current:
            current = row["floor"]
            c.setFillColor(HexColor("#E7ECF2"))
            c.rect(x, y - 3, width, 12, stroke=0, fill=1)
            c.setFillColor(MUTED)
            c.setFont("Helvetica-Bold", 7.5)
            c.drawString(x + 4, y, current.upper())
            y -= 13
        c.setFont("Helvetica", 9)
        c.setFillColor(INK)
        c.drawString(x + 4, y, row["room"])
        c.drawRightString(x + width - 70, y, f"{_fmt(row['w'])} x {_fmt(row['h'])}")
        c.drawRightString(x + width, y, str(row["area"]))
        y -= 12.5


def build_pdf(m: dict, name: str = "") -> bytes:
    buf = io.BytesIO()
    c = canvas.Canvas(buf, pagesize=A4)
    c.setTitle(f"Naksha AI - {name or 'Plan'}")
    c.setAuthor(AUTHOR)
    c.setCreator("Naksha AI")

    W, L = m["W"], m["L"]
    sub = (f"{W} x {L} ft | {m['plot_area']} sq ft | {m['gaj']} gaj | "
           f"{'G+1' if m['master'] else 'Ground floor'} | {m['placed']} bedroom{'' if m['placed'] == 1 else 's'}")
    pages = 3 if m["master"] else 2
    page = 0

    for key, title in (("g", "Ground floor plan"), ("f", "First floor plan")):
        if key == "f" and not m["master"]:
            continue
        page += 1
        _header(c, title, name, sub)
        extra = 3 if key == "f" else 0
        avail_w = PAGE_W - 2 * MARGIN - 34
        avail_h = PAGE_H - 2 * MARGIN - 28 - 40 - 70 - 40
        s = min(avail_w / W, avail_h / (L + extra))
        x0 = MARGIN + (avail_w - W * s) / 2
        y0 = MARGIN + 70 + extra * s
        _draw_plan(c, m, key, x0, y0, s)
        _legend(c, MARGIN, MARGIN + 18)
        _footer(c, page, pages)
        c.showPage()

    page += 1
    _header(c, "Front elevation", name, sub)
    e = min(9.5, 300 / 34, (PAGE_W - 2 * MARGIN - 80) / W)
    ex = MARGIN + 40
    ey = PAGE_H - MARGIN - 56 - (34 * e)
    _draw_elevation(c, m, ex, ey, e)
    _draw_schedule(c, m, MARGIN, ey - 56, PAGE_W - 2 * MARGIN)
    _footer(c, page, pages)
    c.showPage()
    c.save()
    return buf.getvalue()
