// Generates tests/golden.json from the original JavaScript engine (single-file version).
// Usage: node tools/make_golden.js path/to/index.html > tests/golden.json
const fs = require('fs');
const src = fs.readFileSync(process.argv[2], 'utf8');
const a = src.indexOf('function build(S){');
const b = src.indexOf('/* ---------- plan drawing');
const f1 = n => String(Math.round(n * 10) / 10);
const build = new Function('f1', src.slice(a, b) + '\nreturn build;')(f1);
const cases = [];
for (const w of [18, 21, 25, 30, 36])
  for (const l of [30, 36, 40, 50, 60])
    for (const floors of [1, 2])
      for (const beds of [1, 2, 3, 4, 5])
        for (const shop of [true, false])
          for (const store of [true, false])
            cases.push({ w, l, floors, beds, shop, store, sd: shop ? 10 : 8 });
cases.push({ w: 21, l: 40, floors: 2, beds: 3, shop: true, store: true, sd: 14 });
cases.push({ w: 24, l: 45, floors: 2, beds: 4, shop: true, store: false, sd: 8 });
console.log(JSON.stringify(cases.map(p => ({ params: p, result: JSON.parse(JSON.stringify(build(p))) }))));
