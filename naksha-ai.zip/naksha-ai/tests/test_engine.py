"""The Python engine must match the original JavaScript engine exactly.

golden.json holds outputs of the JavaScript version (see tools/make_golden.js).
"""
import json
from pathlib import Path

import pytest

from naksha.engine import build_raw, generate

GOLDEN = json.loads((Path(__file__).parent / "golden.json").read_text())


def same(a, b, path=""):
    if isinstance(a, dict):
        assert set(a) == set(b), f"{path}: keys differ {set(a) ^ set(b)}"
        for k in a:
            same(a[k], b[k], f"{path}/{k}")
    elif isinstance(a, list):
        assert len(a) == len(b), f"{path}: length {len(a)} != {len(b)}"
        for i, (x, y) in enumerate(zip(a, b)):
            same(x, y, f"{path}[{i}]")
    elif isinstance(a, bool) or isinstance(b, bool) or isinstance(a, str) or a is None:
        assert a == b, f"{path}: {a!r} != {b!r}"
    else:
        assert a == pytest.approx(b, abs=1e-9), f"{path}: {a} != {b}"


@pytest.mark.parametrize("case", GOLDEN, ids=lambda c: str(c["params"]))
def test_matches_javascript(case):
    same(case["result"], build_raw(case["params"]))


BASE = dict(w=21, l=40, floors=2, beds=3, shop=True, store=True, sd=10)


def test_three_bedrooms_on_21x40():
    m = generate(BASE)
    assert m["placed"] == 3
    assert (m["gb"], m["fb"]) == (2, 0)
    names = [r["n"] for r in m["g"]["rooms"] + m["f"]["rooms"]]
    assert {"Bedroom 1", "Bedroom 2", "Master Bedroom"} <= set(names)


def test_ground_only_switches_to_g_plus_1_when_beds_do_not_fit():
    m = generate({**BASE, "floors": 1, "beds": 3})
    assert m["auto_upgraded"] is True
    assert m["S"]["floors"] == 2
    assert m["placed"] == 3
    assert "switched to G+1" in m["notes"][0]


def test_ground_only_stays_when_it_fits():
    m = generate({**BASE, "floors": 1, "beds": 2})
    assert m["auto_upgraded"] is False
    assert m["placed"] == 2


@pytest.mark.parametrize("beds", [1, 2, 3, 4, 5])
def test_requested_bedrooms_are_placed_on_g_plus_1(beds):
    assert generate({**BASE, "beds": beds})["placed"] == beds


def test_schedule_skips_passages():
    rooms = [r["room"] for r in generate(BASE)["schedule"]]
    assert "Gali (passage)" not in rooms and "Entry" not in rooms
    assert "Shop (Dukan)" in rooms
