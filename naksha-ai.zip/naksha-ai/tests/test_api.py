import uuid

import pytest

from app import create_app

PARAMS = dict(w=21, l=40, floors=2, beds=3, shop=True, store=True, sd=10)


@pytest.fixture()
def client(tmp_path):
    app = create_app(str(tmp_path / "test.db"))
    app.config["TESTING"] = True
    return app.test_client()


def headers(cid=None):
    return {"X-Client-Id": cid or str(uuid.uuid4())}


def test_health_and_page(client):
    assert client.get("/api/health").json == {"status": "ok"}
    page = client.get("/")
    assert page.status_code == 200 and b"Naksha AI" in page.data
    assert b"Govind Chaurasiya" in page.data


def test_plan_returns_geometry(client):
    r = client.post("/api/plan", json={"params": PARAMS})
    assert r.status_code == 200
    assert r.json["placed"] == 3 and r.json["schedule"]


@pytest.mark.parametrize("bad", [
    {**PARAMS, "w": 5}, {**PARAMS, "beds": 9}, {**PARAMS, "floors": 3},
    {**PARAMS, "w": "21; DROP TABLE projects"}, {**PARAMS, "extra": 1},
])
def test_plan_rejects_bad_input(client, bad):
    assert client.post("/api/plan", json={"params": bad}).status_code == 422


def test_plan_rejects_non_json(client):
    assert client.post("/api/plan", data="hello").status_code == 400


def test_save_list_get_delete(client):
    h = headers()
    r = client.post("/api/projects", json={"name": "Ramesh shop", "params": PARAMS}, headers=h)
    assert r.status_code == 201
    pid = r.json["id"]
    assert r.json["bedrooms"] == 3 and r.json["params"] == PARAMS

    assert [p["name"] for p in client.get("/api/projects", headers=h).json["projects"]] == ["Ramesh shop"]
    assert client.get(f"/api/projects/{pid}", headers=h).json["name"] == "Ramesh shop"
    assert client.delete(f"/api/projects/{pid}", headers=h).status_code == 204
    assert client.get(f"/api/projects/{pid}", headers=h).status_code == 404


def test_plans_are_private_to_each_client(client):
    a, b = headers(), headers()
    pid = client.post("/api/projects", json={"name": "Mine", "params": PARAMS}, headers=a).json["id"]
    assert client.get("/api/projects", headers=b).json["projects"] == []
    assert client.get(f"/api/projects/{pid}", headers=b).status_code == 404
    assert client.delete(f"/api/projects/{pid}", headers=b).status_code == 404
    assert client.get(f"/api/projects/{pid}", headers=a).status_code == 200


def test_client_id_required(client):
    assert client.get("/api/projects").status_code == 400
    assert client.get("/api/projects", headers={"X-Client-Id": "short"}).status_code == 400


def test_name_is_validated_and_stored_as_text(client):
    h = headers()
    assert client.post("/api/projects", json={"name": "   ", "params": PARAMS}, headers=h).status_code == 422
    nasty = "x'); DROP TABLE projects;--"
    assert client.post("/api/projects", json={"name": nasty, "params": PARAMS}, headers=h).status_code == 201
    assert client.get("/api/projects", headers=h).json["projects"][0]["name"] == nasty


def test_save_limit(client):
    h = headers()
    for i in range(50):
        assert client.post("/api/projects", json={"name": f"p{i}", "params": PARAMS}, headers=h).status_code == 201
    assert client.post("/api/projects", json={"name": "one more", "params": PARAMS}, headers=h).status_code == 409


def test_pdf_downloads(client):
    r = client.post("/api/plan/pdf", json={"params": PARAMS, "name": "My plan"})
    assert r.status_code == 200 and r.mimetype == "application/pdf"
    assert r.data.startswith(b"%PDF") and "naksha-my-plan.pdf" in r.headers["Content-Disposition"]
    h = headers()
    pid = client.post("/api/projects", json={"name": "Saved", "params": PARAMS}, headers=h).json["id"]
    r2 = client.get(f"/api/projects/{pid}/pdf", headers=h)
    assert r2.status_code == 200 and r2.data.startswith(b"%PDF")
    assert client.get(f"/api/projects/{pid}/pdf", headers=headers()).status_code == 404
