import uuid

import pytest

from app import create_app
from naksha import ai


def basic(text):
    return ai.parse_basic(text)["params"]


def test_basic_roman_hindi():
    p = basic("21 x 40 ka ghar, aage dukan, 3 bedroom, store room")
    assert (p["w"], p["l"], p["beds"], p["shop"], p["store"], p["floors"]) == (21, 40, 3, True, True, 2)


def test_basic_chaudai_lambai():
    p = basic("21 feet chaudai aur 40 feet lambi ka ghar, dukan, teen kamre")
    assert (p["w"], p["l"], p["beds"]) == (21, 40, 3)


def test_basic_devanagari():
    p = basic("२१ x ४० का घर, दुकान, ३ बेडरूम, स्टोर")
    assert (p["w"], p["l"], p["beds"], p["shop"], p["store"]) == (21, 40, 3, True, True)


def test_basic_no_shop_and_word_numbers():
    p = basic("25 by 50 plot without shop, four bedrooms, G+1")
    assert (p["w"], p["l"], p["beds"], p["shop"], p["floors"]) == (25, 50, 4, False, 2)


def test_basic_smaller_side_is_width():
    p = basic("40 x 21 ka plot")
    assert (p["w"], p["l"]) == (21, 40)


def test_basic_clamps_out_of_range_and_says_so():
    r = ai.parse_basic("50 x 80 ka ghar 3 bedroom")
    assert (r["params"]["w"], r["params"]["l"]) == (36, 60)
    assert any("outside" in a for a in r["assumptions"])


def test_basic_needs_a_plot_size():
    with pytest.raises(ai.ParseError):
        ai.parse_basic("mujhe ek achha ghar chahiye")


@pytest.mark.parametrize("bad", [None, "", "   ", 5, "x" * 301])
def test_validate_text_rejects(bad):
    with pytest.raises(ai.ParseError):
        ai.validate_text(bad)


# ---- route ----

@pytest.fixture()
def client(tmp_path, monkeypatch):
    monkeypatch.delenv("ANTHROPIC_API_KEY", raising=False)
    app = create_app(str(tmp_path / "t.db"))
    return app.test_client()


H = lambda: {"X-Client-Id": str(uuid.uuid4())}


def test_route_without_key_uses_basic_reader(client):
    r = client.post("/api/ai/parse", json={"text": "21 x 40 ka ghar, dukan, 3 bedroom"}, headers=H())
    assert r.status_code == 200 and r.json["source"] == "basic" and r.json["params"]["beds"] == 3


def test_route_validation(client):
    assert client.post("/api/ai/parse", json={"text": "21 x 40"}).status_code == 400
    assert client.post("/api/ai/parse", json={"text": ""}, headers=H()).status_code == 400
    assert client.post("/api/ai/parse", json={"text": "kuch bhi"}, headers=H()).status_code == 400


class FakeResp:
    def __init__(self, payload, status=200):
        self.payload, self.status = payload, status

    def raise_for_status(self):
        if self.status >= 400:
            raise RuntimeError("http error")

    def json(self):
        return self.payload


def tool_reply(**inp):
    return FakeResp({"content": [{"type": "text", "text": "ok"},
                                 {"type": "tool_use", "name": "set_plot", "input": inp}]})


GOOD = dict(w=21, l=40, floors=2, beds=3, shop=True, store=True, sd=10,
            understood="21 x 40 ka ghar, 3 bedroom", assumptions=["Shop depth 10 ft assumed."])


def test_claude_path(client, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    seen = {}

    def fake_post(url, json=None, headers=None, timeout=None):
        seen.update(url=url, body=json, headers=headers)
        return tool_reply(**GOOD)

    monkeypatch.setattr(ai.requests, "post", fake_post)
    r = client.post("/api/ai/parse", json={"text": "21 x 40 ka ghar 3 bedroom"}, headers=H())
    assert r.status_code == 200 and r.json["source"] == "claude"
    assert r.json["params"] == dict(w=21, l=40, floors=2, beds=3, shop=True, store=True, sd=10)
    assert r.json["understood"].startswith("21 x 40")
    assert seen["url"] == "https://api.anthropic.com/v1/messages"
    assert seen["headers"]["x-api-key"] == "sk-test"
    assert seen["body"]["tool_choice"] == {"type": "tool", "name": "set_plot"}
    assert seen["body"]["messages"][0]["content"] == "21 x 40 ka ghar 3 bedroom"


def test_claude_values_are_clamped(client, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    monkeypatch.setattr(ai.requests, "post", lambda *a, **k: tool_reply(**{**GOOD, "w": 90, "beds": 12}))
    r = client.post("/api/ai/parse", json={"text": "bada ghar"}, headers=H())
    assert r.json["params"]["w"] == 36 and r.json["params"]["beds"] == 5
    assert any("outside" in a for a in r.json["assumptions"])


def test_claude_failure_falls_back_to_basic(client, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")

    def boom(*a, **k):
        raise ai.requests.ConnectionError("down")

    monkeypatch.setattr(ai.requests, "post", boom)
    r = client.post("/api/ai/parse", json={"text": "21 x 40 ka ghar 3 bedroom"}, headers=H())
    assert r.status_code == 200 and r.json["source"] == "basic"
    assert "could not be reached" in r.json["assumptions"][0]


def test_claude_reply_without_tool_falls_back(client, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    monkeypatch.setattr(ai.requests, "post", lambda *a, **k: FakeResp({"content": [{"type": "text", "text": "hi"}]}))
    r = client.post("/api/ai/parse", json={"text": "21 x 40 ka ghar"}, headers=H())
    assert r.json["source"] == "basic"


def test_rate_limit_only_applies_to_paid_calls(client, monkeypatch):
    monkeypatch.setenv("ANTHROPIC_API_KEY", "sk-test")
    monkeypatch.setattr(ai.requests, "post", lambda *a, **k: tool_reply(**GOOD))
    h = H()
    codes = [client.post("/api/ai/parse", json={"text": "21 x 40"}, headers=h).status_code for _ in range(10)]
    assert codes[:8] == [200] * 8 and codes[8:] == [429, 429]
    assert client.post("/api/ai/parse", json={"text": "21 x 40"}, headers=H()).status_code == 200
