# Naksha AI

Shop-house floor plan generator. Enter a plot size, floors and bedrooms and get a ground floor plan,
first floor plan, front elevation, room schedule and a PDF. Plans can be saved to a database.

Made by Govind Chaurasiya (AI Engineer).

## Stack

| Part | Tool |
| --- | --- |
| Layout engine | Python (rule-based, no ML model) |
| Text to plan settings | Claude API through `requests` (tool use), with a built-in basic reader as fallback |
| API and web server | Flask |
| Validation | pydantic |
| Database | SQLite (`sqlite3`, parameterised queries) |
| PDF export | ReportLab |
| Frontend | HTML, CSS, vanilla JavaScript, SVG |
| Tests | pytest (243 tests) |

The Python engine reproduces the original JavaScript engine exactly. `tests/golden.json` holds
outputs from the JavaScript version and `tests/test_engine.py` compares against them.

## Describe your house (Hindi or English)

Type a sentence such as `21 x 40 ka ghar, aage dukan, 3 bedroom, store room` and press Naksha banao.
The settings are filled in and the plan is drawn. The page lists anything it had to assume.

* With `ANTHROPIC_API_KEY` set, the sentence goes to Claude, which fills a fixed tool schema
  (`naksha/ai.py`). The model can only set the plot options. Values are clamped to the allowed
  ranges and validated again by the server.
* Without a key, or if the call fails, a basic reader (regular expressions for common Hindi and
  English phrases) is used, so the box always works.
* The sentence is sent to Anthropic when a key is set. Do not put private details in it.
* Paid calls are limited to 8 per minute per browser and 60 per minute overall.
* Set `NAKSHA_MODEL` to change the model (default `claude-sonnet-5-5`).

The Claude request is covered by tests with a mocked response. It has not been run against the live API
from the build environment, so try one sentence after you add your key.

## Run locally

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt
export ANTHROPIC_API_KEY=sk-ant-...   # optional, Windows: set ANTHROPIC_API_KEY=...
python app.py                      # open http://127.0.0.1:5000
```

Run the tests: `python -m pytest -q`

## Deploy (Render, free tier)

1. Push this folder to a GitHub repository.
2. On render.com choose New, then Web Service, and pick the repository.
3. Build command: `pip install -r requirements.txt`
4. Start command: `gunicorn app:app`
5. Under Environment add `ANTHROPIC_API_KEY` (optional, enables the AI reader).
6. Free instances have no permanent disk, so saved plans reset on redeploy.
   For permanent storage add a Render Disk and set the environment variable `NAKSHA_DB=/var/data/naksha.db`.

## API

All bodies are JSON. Saved-plan and AI routes need an `X-Client-Id` header (16 to 64 letters, digits or hyphens).
The page creates one automatically and keeps it in `localStorage`, so each browser only sees its own plans.
This is a privacy separation, not a login.

| Method and path | What it does |
| --- | --- |
| `GET /api/health` | Health check |
| `POST /api/plan` | Body `{"params": {...}}`. Returns the plan geometry, schedule and summary |
| `POST /api/ai/parse` | Body `{"text": "..."}`. Returns `params`, `understood`, `assumptions`, `source` (`claude` or `basic`) |
| `POST /api/plan/pdf` | Body `{"params": {...}, "name": "..."}`. Returns a PDF |
| `GET /api/projects` | List saved plans |
| `POST /api/projects` | Save a plan, body `{"name": "...", "params": {...}}` (up to 50 per client) |
| `GET /api/projects/<id>` | One saved plan |
| `GET /api/projects/<id>/pdf` | PDF of a saved plan |
| `DELETE /api/projects/<id>` | Delete a saved plan |

`params`: `w` (18-36), `l` (30-60), `floors` (1-2), `beds` (1-5), `shop` (bool), `store` (bool), `sd` (8-14, shop depth in ft).

Example:

```bash
curl -s localhost:5000/api/plan -H 'Content-Type: application/json' \
  -d '{"params":{"w":21,"l":40,"floors":2,"beds":3,"shop":true,"store":true,"sd":10}}'
```

## Folder layout

```
app.py              Flask routes
naksha/engine.py    layout engine
naksha/ai.py        sentence to settings (Claude and basic reader)
naksha/db.py        SQLite functions
naksha/pdf.py       ReportLab drawings
naksha/schemas.py   input validation
templates/ static/  page, styles, drawing code
tests/              pytest and golden data
tools/              script that made golden.json from the JavaScript engine
```

## Limits

Layouts are concept drawings, not structural designs. Show them to an architect or engineer before building.
